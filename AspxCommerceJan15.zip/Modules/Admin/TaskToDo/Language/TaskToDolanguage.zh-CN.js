var TaskToDoLanguage = {
"All":"所有",
"Previous":"以前",
"Today":"今天",
"UpComming":"UpComming",
"Add Task":"添加任务",
"Add New":"添加新",
"Update":"更新"
};
