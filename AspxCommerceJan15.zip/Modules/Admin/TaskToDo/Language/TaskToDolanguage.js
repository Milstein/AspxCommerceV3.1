﻿var TaskToDoLanguage = {
    'All': 'All',
    'Previous': 'Previous',
    'Today': 'Today',
     'UpComming': 'UpComming',
     'Add Task': 'Add Task',
     'Add New':'Add New',
     'Update': 'Update'
};