﻿

var AspxAdminNotificationLanguage = {

   "Information Alert":"信息提示",
"Successful Message":"成功的消息",
"Error Message":"错误信息",
"Failed to load control!.":"无法加载控制！",
"Failed to load data!":"无法加载数据！",
"Failed to save!":"无法保存！",
"Saved successfully!":"保存成功！",
"* (no more than 5 digits)": "*（不超过5位）",
//AspxAdminNotificationView.js
"Click to View User Info": "點擊查看用戶信息",
"Recently Registered and Subscribed Users:": "最近註冊和訂閱用戶：",
"There are no Recently Registered or Subscribed Users:": "有沒有最近註冊或已申請的用戶：",
"subscribed on:": "認購於：",
"registered on:": "註冊於：",
"Item Name:": "產品名稱：",
"The following items are Out of Stock or Low of Stock:": "下列項目是缺貨的股票或低的：",
"Out of stock": "缺貨",
"Low stock": "低庫存",
"There are no items Out of Stock or Low of Stock:": "有沒有商品缺貨的股票或低的：",
"Following are the Recent Orders:": "以下是最近的訂單：",
"Order OF ID:": "訂購ID：",
"There are no Recent Orders:": "有沒有最近的訂單：",
"SKU:":"SKU:",
"Admin Notification": "管理通知",
"All Notifications": "所有通知",
"User Registration": "用户注册",
"Subscription": "订阅",
"Orders": "订单",
"Number of notifications to show": "通知显示的数",
"Save": "节省",
"Refresh": "刷新",
"ON": "开",
"OFF": "关闭",
"Settings saved with success!": "保存成功设置！"



};
