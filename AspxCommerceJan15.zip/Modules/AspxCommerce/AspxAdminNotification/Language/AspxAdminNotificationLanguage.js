﻿

var AspxAdminNotificationLanguage = {

       "Information Alert": "Information Alert",
    'Successful Message': 'Successful Message',
    "Error Message": "Error Message",
    "Failed to load control!.": "Failed to load control!.",
    "Failed to load data!": "Failed to load data!",
    "Failed to save!": "Failed to save!",
    "Saved successfully!": "Saved successfully!",
    "* (no more than 5 digits)": "* (no more than 5 digits)",
       "Click to View User Info": "Click to View User Info",
    "Recently Registered and Subscribed Users:": "Recently Registered and Subscribed Users:",
    "There are no Recently Registered or Subscribed Users:": "There are no Recently Registered or Subscribed Users:",
    "subscribed on:": "subscribed on:",
    "registered on:": "registered on:",
     "The following items are Out of Stock or Low of Stock:": "The following items are Out of Stock or Low of Stock:",
    "Out of stock": "Out of stock",
    "Low stock": "Low stock",
    "There are no items Out of Stock or Low of Stock:": "There are no items Out of Stock or Low of Stock:",
    "Following are the Recent Orders:": "Following are the Recent Orders:",
    "Order OF ID:": "Order OF ID:",
    "There are no Recent Orders:": "There are no Recent Orders:",
    "SKU:": "SKU:",
    "Admin Notification":"Admin Notification",
    "All Notifications":"All Notifications",
    "User Registration":"User Registration",
    "Subscription":"Subscription",
    "Orders":"Orders",
    "Number of notifications to show": "Number of notifications  to show",
    "Save":"Save",
    "Refresh": "Refresh",
    "ON":"ON",
    "OFF":"OFF",
    "Settings saved with success!":"Settings saved with success!"

    


};
