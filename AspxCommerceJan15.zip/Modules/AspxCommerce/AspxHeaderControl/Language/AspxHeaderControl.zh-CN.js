﻿

var AspxHeaderControl = {
       "My Account": "我的帐户",
    "My Categories": "我的分类",
    "My Added Items": "我添加的项目",
    "Checkout": "结帐",
    "Close": "关闭",


       "Information Alert": "信息快递",
    "You can't proceed to checkout your amount is not applicable!": "你可以不进行结算的金额是不适用的！",
    "You have not added any items in cart yet!": "你还没有添加任何物品车！",
    "You are not eligible to proceed further. Your order amount must be at least": "你没有资格进行进一步的，因为订单金额低。您的订单金额必须至少",
    "Checkout With Single Address": "结算与单地址",
    "Checkout With Multiple Addresses": "随着多个地址结帐",
    "Checkout is not allowed for anonymous user!": "不允许匿名用户结帐！",
    "OR": "或",
    "My Wishlist": "我的心愿",
    "My Cart": "我的购物车",
    "Notice Information": "公告信息",
    "Your cart contains items. Do you want to look at them?": "您的购物车包含的项目。你想看看他们吗？",
       "Setting Saved Successfully": "设置已保存成功",
    "Header Settings": "页眉设置",
    "Horizontal": "横",
    "Dropdown": "下拉",
    "Save": "节省"
};
