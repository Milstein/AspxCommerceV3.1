var AspxBrowseByCategory = {
    "Browse by": "浏览",
    "No category with item is found!": "没有项目类别找到了！",
    "Setting Saved Successfully": "设置成功保存",
    "Save": "节省"
};
