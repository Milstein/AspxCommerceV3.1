﻿

var Brand = {


       "Top Brands": "顶级品牌",
    "Popular Brands": "热门品牌",

    "loading....": "加载....",
    "View as:": "查看方式:",
    "Sort by:": "排序:",

    "Delete Confirmation": "删除确认",
    "Are you sure you want to delete this brand?": "你确定你要删除这个品牌?",
    "Successful Message": "成功的消息",
    "Error Message": "错误讯息",
    "Failed to delete brand": "无法删除品牌",
    "Editing Brand:": "编辑品牌:",
    "Information Message": "信息消息",
    "error": "错误",
    "Brand has been deleted successfully.": "品牌已成功删除.",
    "Brand DeActivated successfully": "品牌成功停用",
    "Brand Activated successfully": "品牌成功激活",
    "Brand Updated successfully": "品牌更新成功",
    "Brand Inserted successfully": "品牌成功插入",
    "Alert Message": "警报消息",
    "Not a valid image!": "不是有效的图像!",
    "Can not upload the image!": "不能上传图片！",
    "Information Alert": "信息提示",
    "None of the brand are selected": "没有选择的品牌",
    "Do you want to delete?": "你要删除?",
    "Choose Image!": "选择图片!",
    "Brand Exists": "品牌存在",
    "Please choose another brand name": "请选择另一个品牌名称",
    "Please enter brand name!": "请输入品牌名称！",
    "The store has no brand!": "这家商店有没有品牌！",
    "Featured Brands": "特色品牌",
    "The store has no featured brand!": "这家商店有没有特色的品牌！",
    "Please enter valid date!": "请输入有效的日期！",



   
    "Sorry, Failed to load brand items results!": "对不起，无法加载品牌项目的结果！",

       "Brands": "品牌",
    "A-D": "A-D",
    "E-L": "E-L",
    "M-P": "M-P",
    "Q-Z": "Q-Z",
    "View All Brands": "查看所有品牌",
    "All Brands": "所有品牌",
    "BrandID": "品牌标识",
    "Brand Name": "商标名称",
    "Brand Description": "品牌简介",
    "Brand Image": "品牌形象",
    "Slider View": "显示在滑块",
    "Featured": "被推荐",
    "Featured From": "精选自",
    "Featured To": "要精选",
    "Active": "为活跃",
    "Actions": "操作",
    "Edit": "编辑",
    "Delete": "删除",
    "Activate": "激活",
    "Deactivate": "取消激活",
    "No Records Found!": "没有找到记录！",
       "Show All": "显示全部",
    "Add New Brand": "添加新品牌",
    "Delete All Selected": "删除所有选定",
    "Brand Name:": "品牌名称：",
    "Search": "搜索",
    "Save": "节省",
    "Cancel": "取消",
    "Select Langauge:": "选择语言特点："

};
