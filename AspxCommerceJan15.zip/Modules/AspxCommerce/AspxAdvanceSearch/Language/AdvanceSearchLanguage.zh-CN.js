﻿
var AdvanceSearchLang = {


   
"From:":"从：",
"To:":"到：",
"Search":"搜索",
"View as:":"查看：",
"Sort by:":"排序方式：",
"View Per Page":"查看每页",
"General Categories":"一般分类",
"Gift Card Categories":"礼品卡类别",

   
"Valid Digits And Decimal Only":"有效数字和小数点只",
"Information Alert":"信息提示",
"To Price must be greater than From Price":"价格必须大于从价格",
"The selected item already in your wishlist.":"所选择的项目已经在你的心愿。",
"Please select at least one attribute to search.":"请选择搜索至少有一个属性。",
"All Brands":"所有品牌",



   "Advanced Search":"高级搜索",
"Go":"去",

   "Select Category":"选择类别",
"--All Category--":"- 所有分类 -",
"What are you shopping today?":"你逛街什么今天？",
"Popular:":"热门：",
"Setting Saved Successfully":"设置已保存成功",
    "Advance Search Module Setting":"高级搜索模块设置", 
     "Enable Advance Search:":"启用高级搜索：",
     "Enable Brand Search:": "使品牌搜索：",
     "No Of Items in a Row:":"没有在第一排的项目：",
     "Advance Search Page Name:": "高级搜索页面名称：",
     "Save": "节省"


};
