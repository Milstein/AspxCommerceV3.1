var ImportDataLan = {
 "Select File: ": "选择文件: ",
"Alert Message":"警报消息",
"Not a valid file!":"不是一个有效的文件！",
"Error Message":"错误信息",
"Can not upload the file!":"不能上传文件！",
"Imported items and categories successfully":"进口商品和类别成功",
"External table is not in the expected format.":"外部表不是预期的格式。",
"Cost variants data imported successfully":"成本变种数据成功导入",
"Failed to get uploaded data":"无法获取上传的数据",
"Import Manager": "进口部经理"
}
