﻿var ImportDataLan = {
    "Select File: ": "Select File: ",
    "Alert Message": "Alert Message",
    "Not a valid file!": "Not a valid file!",
    "Error Message": "Error Message",
    "Can not upload the file!": "Can not upload the file!",
    "Imported items and categories successfully": "Imported items and categories successfully",
    "External table is not in the expected format.": "External table is not in the expected format.",
    "Cost variants data imported successfully": "Cost variants data imported successfully",
    "Failed to get uploaded data": "Failed to get uploaded data",
    "Import Manager": "Import Manager"
}