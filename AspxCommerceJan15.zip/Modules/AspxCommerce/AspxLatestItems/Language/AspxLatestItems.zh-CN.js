﻿

var AspxLatestItem={


   "View Full Product Detail": "查看全部产品详细信息",
   "Regular Price :":"原价：",
"Our Offer :":"我们的提议：",
"Details":"详情",
"Wishlist":"收藏",
"Compare":"比较",
"More than": "以上",
"Cart +": "购物车+",

"Add to cart":"添加到购物车",
"This store has no items listed yet!":"这家店还没有列出的项目！",
"items are not allowed to add in compare list!":"项目不允许添加在比较列表！",
"The selected item already exist in compare list.":"所选项目中已存在的比较列表。",
"Item has been successfully added to compare list.":"项目已成功地加入到比较列表。",
"The selected item already exist in your wishlist.":"所选的项目已经存在于你的愿望。",

"(Bulk Discount available)":"（散装折扣）",
"Item quantity discounts:":"项目数量折扣：",
"Quantity (more than)":"数量（超过）",
"Add to Cart":"添加到购物车",
"Continue Shopping":"继续购物",
"Close":"关闭",
 
    
      
      "Quick Look":"快速查找",
"Available":"可用的",
"Not Available":"不可用",
"In stock":"库存",
"Out Of Stock":"缺货",
"This product is out of stock!":"此产品脱销！",
"Not required":"不要求",
"Don't use this option":"不要使用此选项",
"Successful Message":"成功的消息",
"Item has been successfully added to cart.":"产品已成功添加到购物车。",
"Failed to load cost variants!":"成本变种加载失败！",
"Failed to save!":"保存失败！",
"Failed to add item to cart!":"添加到购物车失败！",
"Price :":"价格：",
"Price":"价格",
"Invalid quantity.":"无效的数量。",
"Information Alert":"信息提示",
"This product is currently out of stock!":"这款产品目前缺货！",
"Please choose available variants!":"请选择可供变种！",
"The quantity is greater than the available quantity.":"数量大于可用数量。",
"Information Message":"信息消息",
"Item Quantity Discount:":"项目数量折扣：",
"Price Per Unit":"每单位价格",
"Error Message":"错误讯息",
"Brand": "牌",
"View all items under this brand": "这个品牌下的所有项目",
"Note:- select your card theme": "注： - 选择您的贺卡主题",
"Please fill valid required data!": "请填写有效的所需的数据！",
"Price History": "历史价格",
"Date": "日",
"View": "视图",
//LatestItemSettings.ascx
    "Latest Item Settings": "最新的項目設置",
    "Save": "節省",
    "Setting Saved Successfully": "設置已保存成功"

};
