﻿
var AspxMegaCategory = {
    "Categories":"Categories",
    "All Categories": "All Categories",
    "This store has no category found!": "This store has no category found!",
    "Setting Saved Successfully": "Setting Saved Successfully",
       "Mega Category Setting": "Mega Category Setting",
    "Horizontal": "Horizontal",
    "Vertical": "Vertical",
    "Collapseable": "Collapseable",
    "Show":"Show",
    "Slide": "Slide",
    "Fade": "Fade",
    "Right": "Right",
    "Left": "Left",
    "Click": "Click",
    "Hover": "Hover",
    "Save": "Save",
    "fast": "fast",
    "slow":"slow",
    "Please fill all the required form.": "Please fill all the required form."

};