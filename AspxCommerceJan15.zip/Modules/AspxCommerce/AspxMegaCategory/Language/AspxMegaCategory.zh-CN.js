﻿
var AspxMegaCategory = {

   
       "All Categories": "所有分类",
    "Setting Saved Successfully": "设置已保存成功",
    "This store has no category found!": "这家店有没有发现类！",
       "Mega Category Setting": "兆豐類別設置",
    "Horizontal":"横",
    "Vertical": "垂直",
    "Collapseable": "Collapseable",
    "Show":"节目",
    "Slide": "滑",
    "Fade": "褪色",
    "Right": "右边",
    "Left": "左",
    "Click": "点击",
    "Hover": "徘徊",
    "Save": "节省"
};
