

var AspxItemsCompare = {
	//ItemCompareDetails.ascx
"Compare Items":"比较项目",
"No Items found in you Compare Item List.":"你没有发现项目比较项目名单。",
"Error Message":"错误信息",
"Sorry, Compare list error occured!":"很抱歉，比较清单发生错误！",
"Sorry, error occured!":"很抱歉，发生错误！",
"Information Alert":"信息快递",
"The selected item already in your wishlist.":"所选项目已经在你的愿望。",
"Print":"打印",
"Price :":"价格：",
"Add to Cart":"添加到购物车",
"Out Of Stock": "缺货",
"+ Add to Wishlist":"+加入收藏",
"Show Compare Items":"显示项目",

	//ItemsCompare.ascx    
"My Compared Items []":"我比较项目[]",
"Clear All":"全部清除",
"Compare":"比较",
"Variants":"变种",
"Sorry, You can not add more than": "对不起，您不能添加多个",
"items":"项目",


	//ItemsCompare.js

"You must have more than one item to compare!":"你必须有一个以上的项目比较！",
"Delete Confirmation":"删除确认",
"Are you sure you want to delete this item?":"你确定要删除这个项目吗？",
"Are you sure you want to clear compare list?":"你确定你要清除的比较列表吗？",
"My Compared Items":"我比较项目",
"No items have been compared yet!":"没有项目已比较呢！",
"The selected item already exist in compare list.":"选定的项目中已经存在比较列表。",
"Compare +": "比较+",
"Compare": "比较s"
};
