﻿var AspxCategoryLister = {

   
       "This store has no category found!": "这家店没有分类找到！",
    "Categories": "分类",

   
       'home': '家',
    'Shopping Options': '购物选项',

    'Tags': '标签',
    'Search': '搜索'
};