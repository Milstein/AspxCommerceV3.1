﻿var AspxApiJs = {
   
    "Your Wishlist Contains:": "Your Wishlist Contains:",
    "WishList +": "WishList +",
    "My Wishlist":"My Wishlist",
    "Your Wishlist Contains:":"Your Wishlist Contains:",
    "The selected item already exist in your wishlist.":"The selected item already exist in your wishlist.",
    "Information Alert":"Information Alert",
    "Please choose available variants!":"Please choose available variants!",
    "The selected item already exist in wishlist.":"The selected item already exist in wishlist.",
    "Error Message":"Error Message",
    "Failed to add item in wishlist!":"Failed to add item in wishlist!",
    "Successful Message":"Successful Message",
    "Item has been successfully added to wishlist.": "Item has been successfully added to wishlist.",   
    "Advanced Search":"Advanced Search"
};