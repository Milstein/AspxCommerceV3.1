﻿
var AspxApiJs = {
"Your Wishlist Contains:": "您的收藏包含:",
"WishList +": "愿望清单+",
"My Wishlist": "我的收藏",
"Your Wishlist Contains:": "您的收藏包含：",
"The selected item already exist in your wishlist.": "所选择的项目已经存在于你的愿望清单。",
"Information Alert": "信息提示",
"Please choose available variants!": "请选择可用的变种！",
"The selected item already exist in wishlist.": "所选择的项目已经存在于愿望清单。",
"Error Message": "错误信息",
"Failed to add item in wishlist!": "无法在愿望清单添加商品！",
"Successful Message": "成功的消息",
"Item has been successfully added to wishlist.": "商品已成功添加到愿望清单。",
"Advanced Search": "高级搜索"
};