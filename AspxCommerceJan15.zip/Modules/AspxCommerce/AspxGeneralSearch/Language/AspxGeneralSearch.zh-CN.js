﻿
var AspxGeneralSearch = {
   
    "From:": "来自：",
    "To:": "到：",
    "Search": "搜索",
    "View as:": "查看：",
    "Sort by:": "排序方式：",
    "View Per Page": "查看每页",

   
    "Valid Digits And Decimal Only": "只有有效位数和小数",
    "Information Alert": "信息快递",
    "To Price must be greater than From Price": "价格必须大于从价格",
    "The selected item already in your wishlist.": "所选项目已经在你的愿望。",
    "Please select at least one attribute to search.": "请选择至少一个属性进行搜索。",


       "Advanced Search": "高级搜索",
    "Go": "去",

       "Select Category": "选择类别",
    "--All Category--": "- 所有种类 -",
    "What are you shopping today?": "什么是今天你逛街吗？",
    "Popular:": "热门： ",
    "Setting Saved Successfully": "设置成功保存",
       "Search Settings": "搜索设置",
    "Save": "节省",
    "Setting Saved Successfully": "设置已保存成功"
};
