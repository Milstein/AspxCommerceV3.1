﻿

    var AspxCurrencyConverter = {
	   	    "Information Alert": "信息快递",
	    "Unable to connect to the remote server.Please try again later!": "无法连接到远程服务器。请稍后再试！",
	    "Select Currency:": "选择货币单位：",
		"Currency:":"货币："

	       };
