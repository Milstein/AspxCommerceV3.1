﻿

var AspxCurrencyConverter = {

       "Information Alert": "Information Alert",
    "Unable to connect to the remote server.Please try again later!": "Unable to connect to the remote server.Please try again later!",
    "Currency:": "Currency:"

   };