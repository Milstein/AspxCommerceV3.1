var AspxCustomerManagement = {
    
"Are you sure you want to delete customer?":"您确定要删除客户？",
"Sorry! You can not delete yourself.":"对不起！您无法删除自己。",
"Customer ID":"客户ID",
"Culture Name":"文化名",
"Added On":"Added On",
"UpdatedOn":"UpdatedOn",
"is Same User":"是相同的用户",
"Delete":"删除",
"Successful Message":"成功的消息",
"Customer has been deleted successfully.":"客户已成功删除。",
"Selected customer(s) has been deleted successfully.":"特选客户（S）已成功删除。",
"Failed to delete Customer!":"无法删除客户！",
"Error Message":"错误信息",
"Customer has been created successfully.":"客户已成功创建。",
"Delete Confirmation":"删除确认",
"Are you sure you want to delete the selected customer(s)?":"您确定要删除选定的客户（S）？",
"Information Alert":"信息提示",
"Please select at least one customer before delete.":"请在使用前删除至少选择一个客户。",
"Period":"期",
"Number Of New Accounts":"新增开户数",
"User Name":"用户名",
"Session User Host Address":"会话用户主机地址",
"Session User Agent":"会议用户代理",
"Session Browser":"浏览器会话",
"Session URL":"会议网址",
"Start Time":"开始时间",
"No Records Found!":"没有找到记录！",
"Customer Name":"客户名称",
"Total Order Amount":"总订单金额",
"Number Of Orders":"订货数量",
"Average Order Amount":"平均订单金额",
"Actions":"操作",
"Export to CSV":"导出到CSV",
"User Name:":"用户名：",
"Search":"搜索",
"Add New Customer":"添加新客户",
"Delete All Selected":"删除所有选定",
"Fields marked with * are compulsory.": "标有*的字段是强制性的。",
"User Info":"用户信息",
"Create Login":"创建登录",
"Back":"后面",
"Show Reports:":"报告显示：",
"Show Year Monthly Report":"显示出年份月报",
"Show Current Month Weekly Report":"显示当月周报",
"Show Today's Report":"显示今天的报告",
"Host Address:":"主机地址：",
"Browser Name:":"浏览器名称：",
"Customer Name:": "客户名称：",
"Added On": "添加于",
"Updated On": "更新日期",
"View": "视图",
"Register": "注册",
"Wishlist Item has been deleted successfully.":"收藏项目已成功删除。",
"Shopping Cart Item has been deleted successfully.":"购物车项目已成功删除。",
"Are you sure you want to delete the selected shopping cart items(s)?": "您确定要删除所选的购物车中的商品（S）？",
"Please select at least one shopping cart item before delete.":"请在使用前删除至少选择一个购物车的项目。",
"The customer does not have a default Shipping address":"该客户没有默认送货地址"
};
    
    
    
    
    
  
    
    
    
    
    
