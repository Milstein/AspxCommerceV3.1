﻿

var AspxItemDetailTab = {
    "No Data Found!!": "没有找到数据!!",
    "View Per Page:": "每页:",
    "See all pages tagged with": "查看所有标签的页面",
    "Not any items have been tagged yet!": "没有任何项目已标记！",
    "loading....": "加载....",
    "View as:": "查看方式:",
    "your tag(s) has been accepted for moderation.": "您的评论已经被接受适度.",
    "Successful Message": "成功的消息",
    "Failed to save tags!": "无法拯救标签！",
    "Tags": "标签",
    "Popular Tags:": "热门标签:",
    "My Tags:": "我的标签:",
    "Add Tag": "添加标签",
    "Sign in to enter tags": "登录进入标签",
    "Videos": "视频",
    "Item has no any videos.": "项目已没有任何视频.",
    "failed to load video thumbs something goes wrong..!": "无法加载视频大拇指东西出错..!",
    "Error Message": "错误讯息"
};
