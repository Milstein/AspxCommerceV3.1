﻿
var AspxItemDetailTab = {
    "No Data Found!!": "No Data Found!!",
    "View Per Page:": "View Per Page:",
    'See all pages tagged with': 'See all pages tagged with',
    'Not any items have been tagged yet!': 'Not any items have been tagged yet!',
    "View as:": "View as:",
    "your tag(s) has been accepted for moderation.": "your tag(s) has been accepted for moderation.",
    "No items listed yet.": "No items listed yet.",
    "Successful Message": "Successful Message",
    'Failed to load item tags!': 'Failed to load item tags!',
    'Failed to save tags!': 'Failed to save tags!',
    'Tags': 'Tags',
    'Popular Tags:': 'Popular Tags:',
    'My Tags:': 'My Tags:',
    '+ Tag': '+ Tag',
    "Videos": "Videos",
    "Item has no any videos.": "Item has no any videos.",
    'Sign in to enter tags': 'Sign in to enter tags',
    "Error Message": "Error Message"
};