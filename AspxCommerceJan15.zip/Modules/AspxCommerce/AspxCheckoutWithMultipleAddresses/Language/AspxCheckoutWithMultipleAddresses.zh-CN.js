﻿

var AspxCheckoutWithMultipleAddresses={

   
"Your Digital Items":"您的数码产品",
"Ditital Items":"数位压伸项目",
"Edit Items":"编辑项目",
"Quantity":"数量",
"Sub Total":"小计",
"Item":"项目",
"Unit Price":"单价",
"Items":"项目",
"Change":"改变",
"Shipping to":"运输",
"Total Shipping Cost for these items :":"这些项目的总运费 :",
"Shipping Method":"运输方式",
"Total Shipping Cost for these items : 0.00(freeShipping)":"这些项目的总运费：0.00（免费送货）",
"Shipping Total:":"运输总:",
"Grand SubTotal:":"大小计:",
"No Shipping Address Needed":"无需送货地址",
"No Shipping Address Required":"不需要送货地址"
"No Shipping Cost Needed":"无需运费",
"No Items found in your Cart":"没有找到您的购物车",
"Continue to Shopping":"继续购物",
"you have":"你有",
"item that does not meet shipping item weight criteria Or Shipping providers are unable to ship items.":"项目不符合航运重标准或运输商都无法船舶项目s.",
    
"If you still want to checkout then you have to delete that items from your cart to procceed  further process.":"如果你仍然想结账，那么你必须从您的购物车中删除该项目进行进一步处理.",
"Thank you":"谢谢",
"Information Message":"信息消息",
"Your Address Details has not been created Yet!! \n Please Create it to continue..":"详细地址尚未创建！ \ n请继续..",
    
"Total Discount:":"总折扣:",
"Grand Total:":"累计:",
"Information Alert":"信息提示",
"Your cart is not eligible to checkout due to a negatve total amount!":"你的车是由于负的总金额不得检出!"
"Please Select your payment system.":"请选择您的支付系统."
"Enter a New Adddress":"输入新的地址经过",
"Please select shipping address for applicable items":"适用项目，请选择送货地址",
"Shipping Address":"送货地址"
"Continue":"继续"
"Back":"后面"
"Billing to":"计费",
"Payment Methods":"付款方式",
"Additional Note:":"其他注意事项:",
"Total Tax:":"税金总额:",
"Your order has been received":"您的订单已收到",
"Thank you for your purchase!":"感谢您购买!",
"You can check your oder in my oders.":"在我的其他中，您可以检查您的奥德.",
"You will receive an order confirmation email with details of your order and a link to track its progress.":"您将收到订单确认电子邮件，您的订单详情和链接来跟踪其进度.",
    
"Continue Shopping":"继续购物",
"Close":"关闭",
"Save":"节省"
    
    
    
};
    
    
    
        
