﻿

var AspxCheckoutWithMultipleAddresses={

   
    'Your Digital Items':'Your Digital Items',
    'Ditital Items':'Ditital Items',
    'Edit Items':'Edit Items',
    'Quantity':'Quantity',
    'Sub Total':'Sub Total',
    'Item':'Item',
    'Unit Price':'Unit Price',
    'Items':'Items',
    'Change':'Change',
    'Shipping to':'Shipping to',
    'Total Shipping Cost for these items : ':'Total Shipping Cost for these items : ',
    'Shipping Method':'Shipping Method',
    "Total Shipping Cost for these items : 0.00(freeShipping)":"Total Shipping Cost for these items : 0.00(freeShipping)",
    "Shipping Total:":"Shipping Total:",
    "Grand SubTotal:":"Grand SubTotal:",
    'No Shipping Address Needed':'No Shipping Address Needed',
    'No Shipping Address Required':'No Shipping Address Required',    
    'No Shipping Cost Needed':'No Shipping Cost Needed',
    'No Items found in your Cart':'No Items found in your Cart',
    'Continue to Shopping':'Continue to Shopping',
    'you have':'you have',
    'item that does not meet shipping item weight criteria Or Shipping providers are unable to ship items.':'item that does not meet shipping item weight criteria Or Shipping providers are unable to ship items.',
    
    'If you still want to checkout then you have to delete that items from your cart to procceed  further process.':'If you still want to checkout then you have to delete that items from your cart to procceed  further process.',
    'Thank you':'Thank you',
    'Information Message':'Information Message',
    "Your Address Details has not been created Yet!! \n Please Create it to continue..":"Your Address Details has not been created Yet!! \n Please Create it to continue..",
    
    'Total Discount: ':'Total Discount: ',
    'Grand Total: ':'Grand Total: ',
    'Information Alert':'Information Alert',
    'Your cart is not eligible to checkout due to a negatve total amount!':'Your cart is not eligible to checkout due to a negatve total amount!', 
    'Please Select your payment system.':'Please Select your payment system.',    
    "Enter a New Adddress":"Enter a New Adddress",
    "Please select shipping address for applicable items":"Please select shipping address for applicable items",
    "Shipping Address":"Shipping Address",  
    "Continue":"Continue",    
    "Back":"Back",   
    "Billing to":"Billing to",
    "Payment Methods":"Payment Methods",
    "Additional Note:":"Additional Note:",
    "Total Tax:":"Total Tax:",
    "Your order has been received":"Your order has been received",
    "Thank you for your purchase!":"Thank you for your purchase!",
    "You can check your oder in my oders.":"You can check your oder in my oders.",
    " You will receive an order confirmation email with details of your order and a link to track its progress.": "You will receive an order confirmation email with details of your order and a link to track its progress.",
    
    "Continue Shopping":"Continue Shopping",
    "Close":"Close",
    "Save":"Save"  
    
    
    
};
    
    
    
        
