﻿

var AspxBrandView = {
   "Top Brands":"顶级品牌",
"Brands":"品牌",

"loading....":"加载....",
"View as:":"查看：",
"Sort by:":"排序方式：",
"The store has no brand!":"店里有没有品牌！",
"Featured Brands":"推荐品牌",
"The store has no featured brand!":"店里有没有特色的品牌！",
   "Brands":"品牌",
"A-D":"A-D",
"E-L":"E-L",
"M-P":"M-P",
"Q-Z":"Q-Z",
"View All Brands":"查看所有品牌",
"All Brands":"所有品牌",
   "Setting Saved Successfully":"设置已保存成功",
"Brand Settings":"品牌设置",
"Save":"节省",
   "Featured Brands Rss Feed Title":"特色品牌RSS订阅标题",
"Featured Brands Rss Feed Alt":"特色品牌RSS订阅Alt键",
"All Brands Rss Feed Title":"所有品牌行业信息标题",
"All Brands Rss Feed Alt":"所有品牌RSS订阅Alt键",
"This store has no items listed yet!":"这家商店还没有列出任何项目！"
};
