﻿

var AspxBrandView = {
       "Top Brands": "Top Brands",
    "Brands": "Brands",

    "loading....": "loading....",
    "View as:": "View as:",
    "Sort by:": "Sort by:", 
    'The store has no brand!': 'The store has no brand!',
    "Featured Brands": "Featured Brands",
    "The store has no featured brand!": "The store has no featured brand!",
       'Brands': 'Brands',
    'A-D': 'A-D',
    'E-L': 'E-L',
    'M-P': 'M-P',
    'Q-Z': 'Q-Z',
    "View All Brands": "View All Brands",
    "All Brands":"All Brands",
       "Setting Saved Successfully": "Setting Saved Successfully",
    "Brand Settings": "Brand Settings",
    "Save":"Save",
       "Featured Brands Rss Feed Title":"Featured Brands Rss Feed Title",
    "Featured Brands Rss Feed Alt": "Featured Brands Rss Feed Alt",
    "All Brands Rss Feed Title": "All Brands Rss Feed Title",
    "All Brands Rss Feed Alt": "All Brands Rss Feed Alt",
    "This store has no items listed yet!": "This store has no items listed yet!",
    "Please fill all the required form.": "Please fill all the required form."
};